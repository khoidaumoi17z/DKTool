# DangKhoi Tool 1.0 — mẫu byte và phân tích Mach-O

## Giao diện và nhạc nền

Tên hiển thị: **DangKhoi Tool**. Version: **1.0**, build: **1**. Giao diện nền mint sáng, chữ xanh đậm, nút chạm tối thiểu 46 px, bảng địa chỉ cuộn ngang và điều hướng nhanh. Ba bước chính: **Nạp dữ liệu → Đọc kết quả → Patch & xuất**. Phần Khám phá nâng cao có thể mở khi cần. Icon ứng dụng và ảnh đầu trang dùng ảnh bạn cung cấp, đủ kích thước iPhone/iPad/App Store; không tạo nhân vật mới.

Nhạc MP3 bạn gửi được nhúng nguyên file trong bundle, không cần mạng. Player native tự bật mỗi lần khởi chạy, phát lặp đoạn khoảng 32 giây, âm lượng nền 25%. Nút **Tắt nhạc/Bật nhạc** ở đầu giao diện điều khiển trong phiên hiện tại; không lưu trạng thái tắt sang lần khởi chạy mới. Nhạc tạm dừng khi app không còn hoạt động; khi quay lại sẽ tiếp tục nếu đang bật. Cuộc gọi hoặc gián đoạn âm thanh được xử lý theo audio session của iOS. Được cấu hình playback để có thể phát khi máy bật chế độ im lặng; vẫn phụ thuộc âm lượng và thiết bị xuất âm thanh của iPhone.

Dùng AVAudioPlayer trong Swift, tránh giới hạn HTML audio cần thao tác người dùng trong WebView. Không thêm quyền microphone và không cần bật background audio. Tài liệu Apple: https://developer.apple.com/documentation/avfaudio/avaudioplayer/numberofloops

Kiểm tra phiên này: 11 bộ kiểm thử Node/DOM vượt qua, gồm bật/tắt nhạc qua bridge; MP3 giải mã thành công (44,1 kHz, stereo), ảnh icon đúng kích thước/RGB, version/tên/resource trong YAML hợp lệ. Chưa build Xcode hoặc kiểm chứng phát nhạc trên iPhone thật. Workflow GitHub kiểm tra thêm avatar, script nhạc, MP3 trong bundle, tên app và version trước khi đóng gói IPA.

## Patch nhiều offset vào anogs

1. Nạp file **Mach-O** (ví dụ anogs) và chờ nhập hoàn tất. Chức năng patch không sử dụng dump C đơn lẻ hoặc dữ liệu minh họa.
2. Chọn một hàm trong bảng kết quả, bấm **Lấy địa chỉ hàm đang chọn**. App điền VA của hàm; giữ loại địa chỉ VA để tự ánh xạ đúng file offset. Có thể nhập thủ công bằng **File offset**, **VA** hoặc **RVA từ __TEXT**.
3. Ví dụ bạn đưa: chọn **File offset (toàn tệp)**, nhập **0x9FC8**, nhập byte **C0035FD6**. Offset nhập luôn hiểu là hex, kể cả khi không có tiền tố 0x.
4. Bấm **Đọc byte và thêm patch**. App đọc byte từ bản snapshot native đang nạp và hiển thị file offset, VA, byte gốc, byte mới. Trong file anogs bạn cung cấp, ví dụ này là `E12B00B9 → C0035FD6`. Đây chỉ là kiểm tra địa chỉ/byte, không chứng minh chức năng antiban.
5. Lặp lại với các hàm/offset khác để tạo danh sách nhiều patch. Nút **Xóa** trên mỗi dòng bỏ riêng patch đó; **Xóa danh sách patch** bỏ tất cả.
6. Bấm **Xuất file đã patch** → **Lưu vào Tệp**, xuất tên mặc định **anogs.patched**. Đây là bản sao mới, giữ nguyên file gốc và dữ liệu phân tích đang mở. Nếu cần dùng tên anogs, đổi tên bản sao đã lưu. Muốn phân tích nội dung đã sửa, nạp lại bản đã patch.

Mỗi lần xuất đều tạo bản sao từ snapshot gốc, không cộng dồn trên bản xuất trước. Bộ ghi kiểm tra toàn bộ byte gốc trước khi ghi, chặn patch chồng lấn/vượt file/sai độ dài, rồi đọc lại byte mới và kiểm tra kích thước. Khi lỗi, không giữ bản xuất dở. Mỗi patch 4–256 byte (bội số 4), địa chỉ VA căn 4, nằm trọn trong một section mã; tối đa 1.000 patch. Byte thay thế phải khác byte gốc. Không thay header/data/stub và không patch Mach-O đang mã hóa. Giữ giới hạn nhập 100 MiB.

**File offset** tính từ đầu toàn tệp, kể cả tệp FAT; **VA/RVA** được ánh xạ qua section/slice của Mach-O. Không cộng base/slice bằng tay sau khi đã chọn đúng loại địa chỉ. Phần native xuất dùng snapshot và danh sách patch nhỏ, không truyền file 100 MiB về JavaScript để xuất.

`C0 03 5F D6` mã hóa **RET X30**, không tự đặt thanh ghi trả về thành 0. Ghi RET giữa thân hàm có thể bỏ qua khôi phục stack/thanh ghi và gây lỗi. App xác nhận byte và ánh xạ địa chỉ; không xác nhận hiệu quả antiban hoặc khả năng chạy ổn định sau khi sửa. Việc sửa Mach-O làm thay đổi nội dung đã ký; ứng dụng chứa binary có thể cần ký lại. Tool không tự ký lại game.

## Kiểm thử patch

Đã kiểm thử JS/DOM với VA/RVA/file offset, FAT, byte gốc/mới, nhiều patch, chồng lấn, nguồn bị thay đổi, reset/busy và token bản snapshot. Kiểm thử mô phỏng trên file anogs thật tại 0x9FC8 xác nhận chỉ thay 4 byte, giữ kích thước và dữ liệu gốc trong bộ nhớ; không ghi file game đã patch ra đĩa trong phiên này.

Có thêm `Tests/PatchEngineTests.swift` kiểm tra bộ xuất native: copy/ghi/đọc lại, giữ nguyên bản gốc và byte ngoài vùng patch, chặn overlap/out-of-bounds/sai byte gốc, dọn file lỗi. Môi trường hiện tại không có Swift/Xcode nên chưa chạy bài Swift hoặc build IPA tại đây. Workflow GitHub sẽ compile/run bài Swift này trên macOS trước khi build ứng dụng. Chi tiết phân biệt các kiểm thử đã chạy và chưa chạy trong VALIDATION.json.

## Kết quả phân tích giữ từ bản trước trên file anogs đã cung cấp

| Chỉ tiêu | v9 | v11 |
|---|---:|---:|
| Mốc hàm metadata | 13.323 | 13.323 |
| Đầu mối từ 35 điểm | 1 | 28 |
| Đầu mối từ 55 điểm | 0 | 2 |
| Lời gọi import được ánh xạ | 0 | 7.117 |
| XREF chuỗi được nhận | 3 | 3 |

Hai đầu mối từ 55 điểm nằm trong 28 đầu mối từ 35 điểm. Đây là tăng độ bao phủ phân tích, chưa đo được độ chính xác vì chưa có nhãn chức năng hoặc kiểm chứng runtime. Không có bằng chứng để gọi 28 hàm này là 28 offset antiban hiệu quả.

9 mẫu byte người dùng khớp 489 vị trí trong section mã: 484 trùng đầu hàm metadata, 5 nằm bên trong khoảng hàm. Có 6 hàm khớp đầu hàm đồng thời đạt ngưỡng 35 bằng các bằng chứng khác. Các mẫu là phần mở đầu ARM64 lưu thanh ghi/cấp stack; chức năng thông thường cũng có thể dùng cùng byte. Điểm cao nhất trong kết quả mẫu này là 56/100, không phải 56% xác suất antiban.

## Cách đọc kết quả

1. Nạp Mach-O ARM64 đã giải mã, ví dụ file anogs. Giữ giới hạn 100 MiB (104.857.600 byte) mỗi tệp.
2. Chọn **Thăm dò — từ 35 điểm**, giới hạn **50** hoặc **100** để xem hết 28 đầu mối trên file mẫu. Chế độ chặt từ 55 chỉ hiển thị 2 đầu mối. Không ép số hàm khi thiếu bằng chứng.
3. Chọn một dòng để xem điểm thành phần, lời gọi import, nơi kết quả trả về được dùng trong nhánh, mẫu byte và nguồn ánh xạ địa chỉ.
4. Mở **Đối chiếu 9 mẫu byte người dùng** để xem tối đa 100 vị trí khớp. **Xuất tất cả vị trí khớp byte** chứa các vị trí đã giữ, VA/RVA/file offset, hàm chứa vị trí và điểm ưu tiên của hàm. Khớp ở bên trong khoảng hàm không được tự coi là đầu hàm.
5. **Xuất hàm ưu tiên + offset** xuất danh sách theo bộ lọc. **Xuất chẩn đoán phân tích** xuất số lượng/giới hạn/cảnh báo, giúp giải thích vì sao một tệp có ít kết quả.

Tool tìm byte chính xác, đúng thứ tự byte người dùng gửi, chỉ tại địa chỉ căn 4 byte trong vùng mã được hỗ trợ. Không thêm wildcard tùy tiện; mẫu bị thay đổi sẽ không khớp. Dump C không có byte máy đáng tin cậy nên chỉ áp dụng điều kiện C/chuỗi/lời gọi; nạp Mach-O cùng bản để đối chiếu byte. Cùng địa chỉ chưa chứng minh dump và binary cùng phiên bản.

## Thuật toán phân tích

- Đọc LC_DYSYMTAB/indirect symbol table, reserved1/reserved2 của section để ánh xạ tên import vào stub và pointer. Có kiểm tra biên dữ liệu và slice FAT.
- Quét BL, một số BLR qua import pointer, B tail-call tới đích được nhận diện. Nhận tên API dyld, sysctl, đọc/quan sát bộ nhớ với ngữ cảnh lời gọi thực tế.
- Theo dõi nguồn thanh ghi tối đa 12 lệnh/48 byte trong đoạn thẳng: ADR/ADRP, ADD, MOV, một số tải/hằng, giá trị trả về và CMP/CBZ/TBZ/B.cond. Xóa trạng thái khi gặp nhánh, điểm nhập nhánh, thay hàm, ghi đè hoặc lệnh không hỗ trợ. Đây là phân tích cục bộ, chưa có CFG đầy đủ như IDA.
- Mẫu byte chỉ cộng 4 điểm khi trùng đầu hàm metadata và có XREF/điều kiện/lời gọi dùng kết quả trong nhánh. Mẫu đơn lẻ không tạo ứng viên ưu tiên và không đủ xác nhận vai trò bảo mật.
- API quan sát: 6 điểm/tên, tối đa 12; dùng kết quả trong nhánh +24; hội tụ ít nhất 2 nhóm API +8. API chung có thể phục vụ chức năng bình thường, nên điểm bị giới hạn 45 cho một nhóm hoặc 65 cho nhiều nhóm khi thiếu bằng chứng cụ thể. Giữ quy tắc giảm ưu tiên log, hàm tiện ích và vòng đời.
- Giữ các điều kiện C, XREF, tên/chuỗi cụ thể, đối chiếu cấu trúc phiên bản và chỉ truyền ngữ cảnh một bước từ bản trước. Điểm là trọng số ưu tiên đọc, không phải xác suất được hiệu chuẩn.

Không phân giải đầy đủ chained fixups, PAC, dlsym động, Objective-C/CFString, chuỗi mã hóa, luồng qua bộ nhớ hay mọi lệnh ARM64. Các điểm dừng bảo thủ có thể bỏ sót. Tối đa 100.000 quan hệ/import slot, 20.000 XREF/điều kiện/mẫu byte và 200.000 đích nhánh cho theo dõi thanh ghi; báo khi chạm giới hạn. Chưa thể tự xác nhận offset có hiệu quả bỏ qua kiểm tra gian lận. Phải xác định hành vi hàm và đường đi tới quyết định bằng phân tích mã/runtime; nguồn dữ liệu tĩnh không cho biết quyết định ban ở máy chủ.

## Dump C và nhật ký

Giữ bộ nhập theo chunk UTF-8, UTF-16 LE/BE, BOM; nhận nhãn sub_HEX/FUN_HEX và tên đổi trong listing IDA có header địa chỉ. Giữ quét bằng chứng sau phần xem trước bị rút gọn. C# dump.cs, ASM, APK/ELF Android không tự chuyển thành dump C/Mach-O.

Nếu bộ chọn tệp không mở được, chép tệp vào Tệp → Trên iPhone → DangKhoi Tool rồi chọn **Tệp trong ứng dụng**. Log đã sửa để lấy số phiên bản từ bundle thay vì ghi cố định v6. Log bạn gửi ghi nhận file 2.955.456 byte được nhập thành công; nó không ghi lỗi nhập dump C. Chưa có log lỗi dump C mới để tái hiện đúng lỗi trên máy bạn.

## Đối chiếu bản mới

Nạp bản cũ → **Ghi mốc phiên bản** → nạp bản mới → **Đối chiếu bản đang nạp**. Mốc chỉ giữ trong phiên mở app, tối đa 2.000 hàm có điểm từ 35. Kết quả mơ hồ phải đọc lại; độ tương đồng không chứng minh cùng hành vi hoặc nhà phát triển đã thay một offset cụ thể.

## Tạo IPA bằng GitHub

1. Upload **DangKhoi-Tool-iPhone-1.0.zip** vào gốc repository, giữ nguyên tên ZIP.
2. Tạo hoặc thay file **.github/workflows/build-ipa.yml** bằng nội dung **DangKhoi-build-ipa-1.0.yml** đi kèm. Commit lên nhánh mặc định.
3. Mở **Actions → Build DangKhoi Tool 1.0 → Run workflow**.
4. Khi thành công, tải artifact **DangKhoi-Tool-1.0-unsigned-IPA**, giải nén lấy **DangKhoi-Tool-1.0-unsigned.ipa**.
5. Ký IPA bằng chứng chỉ/provisioning phù hợp trước khi cài. Workflow đóng gói bản chưa ký, không yêu cầu secrets ký. Sau khi cài, kiểm tra tiêu đề v1.0.

Workflow chạy 11 bộ kiểm thử Node, compile/run kiểm thử patch Swift rồi dùng XcodeGen/xcodebuild trên macOS, kiểm tra tài nguyên machine.js/signatures.js và đóng gói ứng dụng ARM64. Nếu lỗi, xem bước đỏ hoặc artifact build-log; bước lỗi trước build có thể chưa tạo log.

## Kiểm chứng

Đã chạy 11 bộ kiểm thử Node, kiểm tra cú pháp JavaScript, DOM/cầu nối iOS mô phỏng và phân tích file anogs thật. Bao gồm đủ 9 mẫu byte, đối chứng lệch căn/ngoài mã/sửa byte/mã hóa, ánh xạ FAT/import, ghi đè thanh ghi/nhánh nhập/lệnh chưa hỗ trợ, mẫu byte đơn lẻ và ranh giới nhập 100 MiB. Chi tiết trong VALIDATION.json.

Chưa build bằng Xcode hoặc chạy trên iPhone thật trong môi trường này; workflow GitHub là bước kiểm chứng build. Không có phép đo precision/recall hoặc thử nghiệm hiệu quả antiban. Không kèm binary game trong source ZIP.

Có thể tạo báo cáo tổng hợp cục bộ bằng:

```sh
node Tests/analyze-file.cjs /duong-dan/anogs report.json
```

## Tài liệu tham khảo

- Apple Mach-O loader.h: https://github.com/apple-oss-distributions/xnu/blob/main/EXTERNAL_HEADERS/mach-o/loader.h
- Hex-Rays XREF: https://docs.hex-rays.com/9.0/user-guide/decompiler/interactive/cmd_jump_xref
- IDA imports API: https://ida-domain.docs.hex-rays.com/ref/imports/
- GitHub chạy workflow: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- GitHub tải artifact: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
