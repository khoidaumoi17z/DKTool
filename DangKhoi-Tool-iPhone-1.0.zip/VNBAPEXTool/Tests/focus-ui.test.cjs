const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const web=path.join(__dirname,'../App/Web'),html=fs.readFileSync(path.join(web,'index.html'),'utf8');
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.value='';this.textContent='';this.disabled=false;this.checked=false;this.listeners={};}
 appendChild(e){this.children.push(e);if(this.tagName==='select'&&!this.value)this.value=e.value;return e;}
 append(...es){es.forEach(e=>this.appendChild(e));}replaceChildren(...es){this.children=es;}setAttribute(){}addEventListener(k,f){(this.listeners[k]||=[]).push(f);}get options(){return this.children;}
 click(){this.onclick?.({stopPropagation(){}});for(const f of this.listeners.click||[])f();}
}
const elements=new Map();for(const m of html.matchAll(/<([a-z]+)\b[^>]*\bid="([^"]+)"[^>]*>/g)){const e=new Element(m[1]);const value=/\bvalue="([^"]*)"/.exec(m[0]);if(value)e.value=value[1];elements.set(m[2],e);}
for(const [id,value] of Object.entries({analysisDepth:'2',analysisDirection:'both',analysisHubLimit:'64',analysisMinGroups:'0',analysisSort:'evidence',focusMode:'strict',focusLimit:'5'}))elements.get(id).value=value;
const el=id=>{assert(elements.has(id),'Missing HTML control '+id);return elements.get(id);},posts=[],context={document:{getElementById:el,createElement:t=>new Element(t),querySelectorAll:()=>[]},console,TextDecoder,Uint8Array,atob,setTimeout,clearTimeout,webkit:{messageHandlers:{iosDesk:{postMessage:p=>posts.push(p)}}}};
context.window=context;vm.createContext(context);
for(const script of html.matchAll(/<script(?: src="([^"]+)")?>([\s\S]*?)<\/script>/g)){vm.runInContext(script[1]?fs.readFileSync(path.join(web,script[1]),'utf8'):script[2],context,{filename:script[1]||'index-inline'});}
function load(text){const b=Buffer.from(text);context.OffsetIOS.setImportBusy(true);context.OffsetIOS.begin('dump','test.c',b.length);for(let i=0;i<b.length;i+=7)context.OffsetIOS.append(b.subarray(i,i+7).toString('base64'));context.OffsetIOS.finish();}
load(Array.from({length:12},(_,i)=>`void sub_${(0x1000+i*16).toString(16)}(){if(CheckHook())return -1;}`).join('\n'));
assert.equal(el('focusRows').children.length,5);el('focusRows').children[0].click();assert.match(el('focusDetail').textContent,/Điều kiện C: CheckHook/);assert.match(el('details').textContent,/sub_1000/);assert.equal(el('generate').disabled,true);
el('focusExport').click();const exported=JSON.parse(posts.at(-1).text);assert.equal(exported.functions.length,5);assert.equal(exported.functions[0].address.fileOffset,null);assert.equal(exported.functions[0].address.rva,null);
el('focusLimit').value='3';el('focusLimit').onchange();assert.equal(el('focusRows').children.length,3);
context.OffsetIOS.setImportBusy(true);assert(el('focusExport').disabled);const previous=el('focusDetail').textContent;el('focusRows').children[1].click();assert.equal(el('focusDetail').textContent,previous);context.OffsetIOS.cancel();assert(!el('focusExport').disabled);
el('reset').click();assert.equal(el('focusRows').children.length,0);assert(el('focusExport').disabled);assert.match(el('focusSummary').textContent,/Nạp Mach-O/);
load('void sub_9000(){puts("integrity checksum");}');assert.equal(el('focusRows').children.length,0);assert.match(el('focusSummary').textContent,/Chưa có hàm/);
context.OffsetIOS.musicState(true,true,'');assert.equal(el('musicLabel').textContent,'Nhạc nền đang phát');el('musicToggle').click();assert.equal(posts.at(-1).action,'music');assert.equal(posts.at(-1).enabled,false);context.OffsetIOS.musicState(false,false,'');assert.equal(el('musicToggle').textContent,'Bật nhạc');
assert(el('patchPreview').disabled);assert(el('patchExport').disabled);
console.log('PASS full page scripts with DOM simulation: bridge -> parser -> rank -> top-5 table, selection, JSON typed offsets, busy state and reset.');
(async()=>{
const body='int v1=CheckHook();if(v1){puts("jailbreak detected");ReportSecurity();return -1;}if(CheckDebugger()){puts("debugger attached");return -2;}return 0;';
load('int sub_1000(){'+body+'}');el('diffRemember').click();assert.match(el('diffSummary').textContent,/Đã giữ 1/);
el('reset').click();assert.match(el('diffSummary').textContent,/Đã giữ 1/);
load('int sub_9000(){'+body+'}');el('diffCompare').click();assert(el('diffCompare').disabled);assert(el('binary').disabled);
await new Promise(resolve=>setTimeout(resolve,25));assert.match(el('diffSummary').textContent,/1 \/ 1/);assert.equal(el('diffRows').children.length,1);assert(!el('binary').disabled);
el('diffExport').click();const report=JSON.parse(posts.at(-1).text);assert.equal(report.matches[0].oldVA,'0x1000');assert.equal(report.matches[0].candidates[0].va,'0x9000');
el('diffRows').children[0].click();assert.match(el('details').textContent,/sub_9000/);
el('diffForget').click();assert(el('diffCompare').disabled);assert(el('diffExport').disabled);
console.log('PASS v9 UI baseline survives reset, comparison async busy lock, changed addresses, report export, selection and forget.');
})().catch(e=>{console.error(e);process.exitCode=1;});
