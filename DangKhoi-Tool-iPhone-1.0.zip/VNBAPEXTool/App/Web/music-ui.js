(function(){'use strict';
const button=document.getElementById('musicToggle'),label=document.getElementById('musicLabel'),dot=document.getElementById('musicDot');let enabled=true;
window.MusicUI={state(on,playing,error){enabled=!!on;button.textContent=enabled?'Tắt nhạc':'Bật nhạc';button.setAttribute('aria-pressed',String(enabled));dot.className=playing?'music-dot playing':'music-dot';label.textContent=error?'Nhạc chưa phát được':playing?'Nhạc nền đang phát':enabled?'Nhạc nền sẵn sàng':'Nhạc nền đã tắt';label.title=error||'';}};
button.onclick=()=>{const handler=window.webkit?.messageHandlers?.iosDesk;if(handler)handler.postMessage({action:'music',enabled:!enabled});else{label.textContent='Nhạc tự động khả dụng trong ứng dụng iPhone.';}};
})();
