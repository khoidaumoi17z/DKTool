(function(){
'use strict';
let busy=false;
const ids=['dumpAsm','dumpHex','dumpBin'];
function section(){const value=document.getElementById('dumpSection').value;return value===''?null:model?.sections[Number(value)];}
function fileRange(s){
 if(!model||!s||s.size===0n||[1,12,18].includes(s.flags&255))return null;
 const start=model.map(s.va),end=model.map(s.va+s.size-1n);
 if(!start||!end||end.fileOffset!==start.fileOffset+s.size-1n)return null;
 return start;
}
function refreshButtons(){const s=section(),valid=!!fileRange(s),native=!!window.webkit?.messageHandlers?.iosDesk;
 for(const id of ids)document.getElementById(id).disabled=busy||!valid||!native;
 if(s&&model?.encrypted)document.getElementById('dumpAsm').disabled=true;
}
function choose(){const s=section();document.getElementById('dumpStart').value='0x0';document.getElementById('dumpLength').value=s?OffsetDesk.hex(s.size):'0x0';
 const r=fileRange(s);document.getElementById('dumpInfo').textContent=s?`${s.segment},${s.name} · VA ${OffsetDesk.hex(s.va)} · file ${r?OffsetDesk.hex(r.fileOffset):'không có byte trong file'} · size ${OffsetDesk.hex(s.size)}`:'Chưa có file.';refreshButtons();
}
window.refreshDumpSections=function(){const select=document.getElementById('dumpSection');select.replaceChildren();
 if(model)for(let i=0;i<model.sections.length;i++){const s=model.sections[i];if(!fileRange(s))continue;const o=document.createElement('option');o.value=String(i);o.textContent=`${s.segment},${s.name} (${OffsetDesk.hex(s.size)} byte)`;select.appendChild(o);}
 if(!select.options.length){const o=document.createElement('option');o.value='';o.textContent='Không có section có dữ liệu';select.appendChild(o);}
 choose();
};
window.setDumpBusy=function(value){busy=!!value;refreshButtons();};
const oldRebuild=window.rebuild;window.rebuild=function(){oldRebuild();window.refreshDumpSections();};
document.getElementById('dumpSection').onchange=choose;
function request(mode){try{
 const s=section(),r=fileRange(s);if(!s||!r)throw Error('Chọn section có dữ liệu trong file.');
 const parse=id=>{const value=document.getElementById(id).value.trim();if(!/^(0x[0-9a-f]+|[0-9]+)$/i.test(value))throw Error('Dùng số thập phân hoặc 0xHEX.');return BigInt(value);};
 const start=parse('dumpStart'),length=parse('dumpLength');
 if(!length||start>=s.size||length>s.size-start)throw Error('Vùng dump vượt section hoặc có độ dài bằng 0.');
 if(length>BigInt(mode===0?100:64)*1024n*1024n)throw Error('Vùng dump quá lớn; chia nhỏ bằng bắt đầu và số byte.');
 if(mode===2){if(model.encrypted)throw Error('File còn mã hóa: chỉ xuất BIN/HEX.');if((s.va+start)%4n)throw Error('Địa chỉ ARM64 phải chia hết cho 4.');if(!(s.name==='__text'||(s.flags&0x80000400)!==0))throw Error('Section này không được đánh dấu chứa mã; dùng BIN/HEX.');}
 report('Đang tạo dump, vui lòng chờ…');
 window.webkit.messageHandlers.iosDesk.postMessage({action:'dump',mode,offset:OffsetDesk.hex(r.fileOffset+start),address:OffsetDesk.hex(s.va+start),length:OffsetDesk.hex(length),encrypted:model.encrypted});
 }catch(e){report(e.message);}}
document.getElementById('dumpAsm').onclick=()=>request(2);document.getElementById('dumpHex').onclick=()=>request(1);document.getElementById('dumpBin').onclick=()=>request(0);
})();
