/* Bounded structural sketches for manual cross-version review, not identity proofs. */
(function(root){
'use strict';
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function normalize(token){if(/^(?:sub_|FUN_)[0-9a-f]+$/i.test(token))return 'callee';if(/^[av]\d+$/.test(token))return 'local';if(/^0x[0-9a-f]{5,}$/i.test(token))return 'address';return token;}
function sketch(mode){let count=0,history=[],values=[],kept=new Set();return {push(token){count++;history.push(hash(String(token)));if(history.length>4)history.shift();if(history.length<4)return;let h=2166136261;for(const x of history)h=Math.imul(h^x,16777619)>>>0;if(kept.has(h)||(values.length===16&&h>=values[15]))return;values.push(h);values.sort((a,b)=>a-b);kept.add(h);if(values.length>16)kept.delete(values.pop());},finish(){return {schema:1,mode,count,hashes:values.slice()};}};}
function armWord(w){
 if((w>>>26)===0x25||(w>>>26)===0x05)return (w&0xfc000000)>>>0;
 if((w&0x1f000000)===0x10000000)return (w&0x9f00001f)>>>0;
 if(((w&0x7e000000)>>>0)===0x34000000)return (w&0xff00001f)>>>0;
 if(((w&0x7e000000)>>>0)===0x36000000)return (w&0xfff8001f)>>>0;
 if(((w&0xff000010)>>>0)===0x54000000)return (w&0xff00001f)>>>0;
 if(((w&0x7f000000)>>>0)===0x11000000)return (w&0xffc003ff)>>>0;
 return w>>>0;
}
function stableName(s){return s&&!/^(?:_*)(?:sub_|FUN_|func_|loc_)[0-9a-f]+$/i.test(s)?String(s).replace(/^_+/,'').toLowerCase():'';}
function features(row,model){
 const refs=root.OffsetAssessment.referenceEvidence(row,model),evidence=[...(row.evidence||[]),...refs];
 const strings=new Set(row.stringAnchors||[]);
 for(const e of evidence)if(e.kind==='keyword'&&/Chuỗi|chuỗi/.test(e.where||''))strings.add(hash(e.excerpt));
 const calls=[...new Set((row.calls||[]).map(stableName).filter(Boolean))].sort().slice(0,32);
 const shapes=[row.controlFlow?.fingerprint,row.binaryFingerprint].filter(s=>s?.schema===1);
 return {name:stableName(row.name),strings:[...strings].sort((a,b)=>a-b).slice(0,32),calls,shapes};
}
function similarity(a,b){if(!a.length||!b.length)return 0;const set=new Set(a),other=new Set(b);let shared=0;for(const x of other)if(set.has(x))shared++;return shared/(set.size+other.size-shared);}
function compareFeatures(a,b){
 let structure=0,shared=0,mode=null;
 for(const x of a.shapes)for(const y of b.shapes){if(x.mode!==y.mode||x.hashes.length<8||y.hashes.length<8||Math.min(x.count,y.count)/Math.max(x.count,y.count)<0.5)continue;const s=similarity(x.hashes,y.hashes);if(s>structure){structure=s;shared=x.hashes.filter(h=>y.hashes.includes(h)).length;mode=x.mode;}}
 const strings=similarity(a.strings,b.strings),calls=similarity(a.calls,b.calls),name=a.name&&a.name===b.name?1:0;
 const score=Math.round(55*structure+20*strings+15*calls+10*name);
 return {score,structure,shared,mode,strings,calls,name,corroboration:Number(strings>0)+Number(calls>0)+Number(name>0)};
}
function keys(f){return [...f.shapes.flatMap(s=>s.hashes.map(h=>s.mode+':'+h)),...f.strings.map(h=>'s:'+h),...(f.name?['n:'+f.name]:[])];}
function snapshot(rows,model,ranked,meta={}){const seen=new Set(),eligible=ranked.filter(r=>{const key=r.va.toString();if(r.score<35||seen.has(key))return false;seen.add(key);return true;}),chosen=eligible.slice(0,2000);return {schema:1,meta:{...meta},functions:chosen.map(r=>({name:r.name,va:r.va,score:r.score,features:features(rows[r.rowIndex],model)})),truncated:eligible.length>chosen.length};}
function compare(snapshot,rows,model){
 const wanted=new Set(snapshot.functions.flatMap(f=>keys(f.features))),index=new Map(),cache=new Map();let skippedCommon=0,postings=0,indexLimited=false;
 rows.forEach((r,i)=>{const f=features(r,model);for(const key of keys(f)){if(!wanted.has(key))continue;if(postings>=300000){indexLimited=true;continue;}if(!index.has(key))index.set(key,[]);const list=index.get(key);if(list===null)continue;if(list.length>=200){index.set(key,null);skippedCommon++;}else {list.push(i);postings++;}}});
 let limited=indexLimited;
 function candidateAddress(i){const r=rows[i],m=model?.map(r.va),code=!!model?.codeSection(r.va);return {va:r.va,rva:m&&code?r.va-model.base:null,fileOffset:m&&code?m.fileOffset:null,mapped:!model||!!(m&&code)};}
 function featureAt(i){if(cache.has(i))return cache.get(i);const f=features(rows[i],model);if(cache.size>=2048)cache.delete(cache.keys().next().value);cache.set(i,f);return f;}
 const matches=snapshot.functions.map(old=>{const hits=new Map();let localLimited=indexLimited;for(const key of keys(old.features)){if(index.get(key)===null)localLimited=true;for(const i of index.get(key)||[]){if(!hits.has(i)&&hits.size>=1000){limited=true;localLimited=true;continue;}hits.set(i,(hits.get(i)||0)+1);}}
  const candidates=[...hits].sort((a,b)=>b[1]-a[1]||a[0]-b[0]).slice(0,50).map(([i])=>({rowIndex:i,name:rows[i].name,va:rows[i].va,address:candidateAddress(i),...compareFeatures(old.features,featureAt(i)),addressConflict:!!rows[i].addressConflict})).sort((a,b)=>b.score-a.score||a.rowIndex-b.rowIndex);
  if(hits.size>50){localLimited=true;limited=true;}const best=candidates[0],margin=best?best.score-(candidates[1]?.score||0):0;
  const supported=!localLimited&&best&&best.score>=70&&best.structure>=0.65&&best.shared>=8&&best.corroboration>0&&margin>=12&&!best.addressConflict&&best.address.mapped;
  return {oldName:old.name,oldVA:old.va,status:supported?'Có bằng chứng tương đồng':best?.score>=35?'Mơ hồ — cần đối chiếu':'Chưa đủ bằng chứng',supported:!!supported,searchLimited:localLimited,margin,candidates:candidates.filter(c=>c.score>0).slice(0,3)};
 });
 // Prevent two old functions being silently assigned to the same new function.
 const claimed=new Map();for(const m of matches)if(m.supported){const key=m.candidates[0].va.toString();if(!claimed.has(key))claimed.set(key,[]);claimed.get(key).push(m);}
 for(const group of claimed.values())if(group.length>1)for(const m of group){m.supported=false;m.status='Mơ hồ — nhiều hàm cũ cùng khớp';}
 return {matches,stats:{oldFunctions:snapshot.functions.length,newFunctions:rows.length,supported:matches.filter(m=>m.supported).length,commonFeaturesSkipped:skippedCommon,candidateLimitReached:limited},notice:'Structural similarity is not identity, functionality or antiban probability. Recheck new-version addresses and behavior.'};
}
const api={hash,normalize,sketch,armWord,features,compareFeatures,snapshot,compare};root.OffsetFingerprint=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
